package com.flightBooking.controller;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/flights")
public class FlightsController {
    @GetMapping
    public String getAllFlights(@RequestParam(defaultValue = "asc") String sort) {
        return "Returning all flights sorted in " + sort + " order";
    }

    @GetMapping("/{id}")
    public String getFlightById(@PathVariable Long id) {
        return "Flight details for ID: " + id;
    }

    @GetMapping("/{id}/schedules")
    public String getSchedulesByFlightAndDate(@PathVariable Long id, @RequestParam String dates) {
        return "Schedules for flight ID " + id + " on dates " + dates;
    }
}
