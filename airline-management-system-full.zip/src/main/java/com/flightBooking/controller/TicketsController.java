package com.flightBooking.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/tickets")
public class TicketsController {
    @PostMapping
    public String bookTicket() {
        return "Ticket booked";
    }

    @GetMapping("/{id}")
    public String getTicket(@PathVariable Long id) {
        return "Ticket details for ID: " + id;
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> cancelTicket(@PathVariable Long id) {
        return ResponseEntity.ok("Ticket cancelled for ID: " + id);
    }
}
