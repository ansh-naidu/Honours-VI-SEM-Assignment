# Airline Management System

A Spring Boot-based Airline Management System with RESTful APIs.

## Endpoints

### Flights
- GET `/flights?sort=asc` - Get all flights
- GET `/flights/{id}` - Get flight by ID
- GET `/flights/{id}/schedules?dates=` - Get flight schedules for a specific date

### Tickets
- POST `/tickets` - Create/book a ticket
- GET `/tickets/{id}` - Get ticket details
- DELETE `/tickets/{id}` - Cancel a ticket
